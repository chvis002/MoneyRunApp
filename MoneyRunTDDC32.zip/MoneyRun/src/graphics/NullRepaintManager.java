package graphics;

import javax.swing.RepaintManager;
import javax.swing.JComponent;

/**
 * NullRepaintManager skriver �ver repaint-funktioner som inte 
 * ska anv�ndas n�r vi manuellt ritar om sk�rmen
 * detta f�r att f�rb�ttra prestandan
 * 
 * @author Christopher Visser & Victor S�derberg
 *
 */
public class NullRepaintManager extends RepaintManager {

	/**
	 * Installerar NullRepaintManager
	 */
    public static void install() {
        RepaintManager repaintManager = new NullRepaintManager();
        repaintManager.setDoubleBufferingEnabled(false);
        RepaintManager.setCurrentManager(repaintManager);
    }

    public void addInvalidComponent(JComponent c) {
        // G�r ingenting
    }

    public void addDirtyRegion(JComponent c, int x, int y, int w, int h) {
        // G�r ingenting
    }

    public void markCompletelyDirty(JComponent c) {
    	// G�r ingenting
    }

    public void paintDirtyRegions() {
    	// G�r ingenting
    }

}