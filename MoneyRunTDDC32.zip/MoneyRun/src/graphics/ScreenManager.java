package graphics;

import java.awt.*;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.lang.reflect.InvocationTargetException;
import javax.swing.JFrame;

/**
 * ScreenManager hanterar initiering och visandet av 
 * fullsk�rmsl�get 
 * 
 * @author Christopher Visser & Victor S�derberg
 *
 */
public class ScreenManager {

	private GraphicsDevice device;

	/**
	 * Skapar en ScreenManager
	 */
	public ScreenManager() {
		GraphicsEnvironment environment =
			GraphicsEnvironment.getLocalGraphicsEnvironment();
		device = environment.getDefaultScreenDevice();
	}

	/**
	 * Returnerar kompibatibla visningsl�gen med systemet
	 * @return DisplayMode[] de l�gen som g�r att visa
	 */
	public DisplayMode[] getCompatibleDisplayModes() {
		return device.getDisplayModes();
	}


	/**
	 * Returnerar det f�rsta visningsl�get som �r kompibatibelt
	 * @param modes De visningsl�gen som ska j�mf�ras
	 * @return Det f�rsta matchande visningsl�get <br>
	 * <code>null</code> om inget l�ge hittas
	 */
	public DisplayMode findFirstCompatibleMode(DisplayMode modes[]) {
		DisplayMode goodModes[] = device.getDisplayModes();
		for (int i = 0; i < modes.length; i++) {
			for (int j = 0; j < goodModes.length; j++) {
				if (displayModesMatch(modes[i], goodModes[j])) {
					return modes[i];
				}
			}

		}

		return null;
	}


	/**
	 * Returnerar nuvarande visningsl�ge
	 */
	public DisplayMode getCurrentDisplayMode() {
		return device.getDisplayMode();
	}

	/**
	 * Unders�ker om tv� visningsl�gen matchar. 
	 * @param mode1 Visningsl�ge 1
	 * @param mode2 Visningsl�ge 2
	 * @return <code>true</code> om de matchar<br>
	 * <code>null</code> annars
	 */
	public boolean displayModesMatch(DisplayMode mode1, DisplayMode mode2){

		if (mode1.getWidth() != mode2.getWidth() ||
				mode1.getHeight() != mode2.getHeight()){
			
			return false;
		}

		if (mode1.getBitDepth() != DisplayMode.BIT_DEPTH_MULTI &&
				mode2.getBitDepth() != DisplayMode.BIT_DEPTH_MULTI &&
				mode1.getBitDepth() != mode2.getBitDepth()){
			
			return false;
		}

		if (mode1.getRefreshRate() !=
			DisplayMode.REFRESH_RATE_UNKNOWN &&
			mode2.getRefreshRate() !=
				DisplayMode.REFRESH_RATE_UNKNOWN &&
				mode1.getRefreshRate() != mode2.getRefreshRate()){
			
			return false;
		}

		return true;
	}


	/**
	 * S�tter fullsk�rmsl�ge. Visningsl�get anv�nder en 
	 * BufferStrategyu med 2 buffrar
	 * @param displayMode Det visningsl�get som ska vara 
	 * fullsk�rmsl�get
	 */
	public void setFullScreen(DisplayMode displayMode) {
		final JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setUndecorated(true);
		frame.setIgnoreRepaint(true);
		frame.setResizable(false);

		device.setFullScreenWindow(frame);

		if (displayMode != null &&
				device.isDisplayChangeSupported()) {
			
			try {
				device.setDisplayMode(displayMode);
			}
			catch (IllegalArgumentException ex) { 
				//G�r ingenting
			}
			frame.setSize(displayMode.getWidth(),
					displayMode.getHeight());
		}
		try {
			EventQueue.invokeAndWait(new Runnable() {
				public void run() {
					frame.createBufferStrategy(2);
				}
			});
		}
		catch (InterruptedException ex) {
			// G�r ingenting
		}
		catch (InvocationTargetException  ex) {
			// G�r ingenting
		}

	}

	/**
	 * H�mtar den grafik som ska visas. D� ScreenManager anv�nder 
	 * en dubbelbufferstrategi s� m�ste aplicationen anropa
	 * update() f�r att visa grafiken.
	 * 
	 * @return Strategins graphics <br>
	 * <code>null</code> om l�get ej �r i fullsk�rm
	 */
	public Graphics2D getGraphics() {
		Window window = device.getFullScreenWindow();
		if (window != null) {
			BufferStrategy strategy = window.getBufferStrategy();
			return (Graphics2D)strategy.getDrawGraphics();
		}
		else {
			return null;
		}
	}

	/**
	 * Uppdaterar och ritar ut p� sk�rmen
	 */
	public void update() {
		Window window = device.getFullScreenWindow();
		if (window != null) {
			BufferStrategy strategy = window.getBufferStrategy();
			if (!strategy.contentsLost()) {
				strategy.show();
			}
		}

	}

	/**
	 * Returnerar dert f�nstret som anv�nds f�r tillf�llet
	 * @return Den aktulla JFramen <br>
	 * <code>null</code> om f�nstret ej �r i fullsk�rmsl�ge
	 */
	public JFrame getFullScreenWindow() {
		return (JFrame)device.getFullScreenWindow();
	}

	/**
	 * @return f�nstrets bredd <br>
	 * <code>null</code> om f�nstret ej �r i fullsk�rmsl�ge
	 */
	public int getWidth() {
		Window window = device.getFullScreenWindow();
		if (window != null) {
			return window.getWidth();
		}
		else {
			return 0;
		}
	}

	/**
	 * @return f�nstrets h�jd <br>
	 * <code>null</code> om f�nstret ej �r i fullsk�rmsl�ge
	 */
	public int getHeight() {
		Window window = device.getFullScreenWindow();
		if (window != null) {
			return window.getHeight();
		}
		else {
			return 0;
		}
	}

	/**
	 * �terst�ller fr�n fullsk�rmsl�ge
	 */
	public void restoreScreen() {
		Window window = device.getFullScreenWindow();
		if (window != null) {
			window.dispose();
		}
		device.setFullScreenWindow(null);
	}

	/**
	 * Skapar en bild som �r kompibatibel med det aktuella 
	 * visningsl�get
	 * @param w bildens bredd
	 * @param h bildens h�jd
	 * @param transparancy transpatricyl�get
	 * @return Den kopibatibla bilden
	 */
	public BufferedImage createCompatibleImage(int w, int h, int transparancy) {
		Window window = device.getFullScreenWindow();
		if (window != null) {
			GraphicsConfiguration gc =
				window.getGraphicsConfiguration();
			return gc.createCompatibleImage(w, h, transparancy);
		}
		return null;
	}
}
