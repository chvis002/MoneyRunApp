package tileManager;


import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Iterator;

import graphics.*;
import input.*;
import sprites.*;


/**
 * GameMangager hanterar alla delar som anv�nds n�r spelet k�rs
 * @author Christopher Visser & Victor S�derberg
 *
 */

public class GameManager extends GameCore {

    public static void main(String[] args) {
        new GameManager().run();
    }

    public static final float GRAVITY = 0.002f;

    private Point pointCache = new Point();
    private TileMap map;
    
    //Managers
    private ResourceManager resourceManager;
    private InputManager inputManager;
    private TileMapRenderer renderer;
    
    //Meny
    private Menu menu;
    
    private ScoreType score;
    private int lives;

    //Inmatningsm�jligheter
    private GameAction moveLeft;
    private GameAction moveRight;
    private GameAction jump;
    private GameAction pause;
    private GameAction moveUp;
    private GameAction moveDown;
    private GameAction accept;
    private GameAction menuLeft;
    private GameAction menuRight;
    
    private boolean isPaused = true;

    
    /**
     * Initierar spelet genom att starta managers samt initiera score och liv.
     * Laddar en tom bana och pausar spelet (startar menyn)
     */
    public void init() {
        super.init();

        // initiera InputManager
        initInput();

        // Starta ResourceManager
        resourceManager = new ResourceManager(
        screen.getFullScreenWindow().getGraphicsConfiguration());

        // Ladda Resources
        renderer = new TileMapRenderer();
        renderer.setBackground(
        		resourceManager.loadImage("background2.png"));
        
        menu = new Menu(resourceManager.loadImage("menu.png"),
        		resourceManager.loadImage("menudot.png"),
        		resourceManager.loadImage("nameInput.png"),
        		resourceManager.loadImage("nameline.png"));

        
        // Skapa ScoreType och s�tt liv
        score = new ScoreType();
        lives = 2;
        
        // Ladda en tom bana
        map = resourceManager.loadEmptyMap();
        
    }

    /**
     * Avslutar spelloopen. �rver fr�n GameCore
     */
    public void stop() {
        super.stop();
    }
    
    /**
     * Laddar om grundv�rden f�r spelsessionen (score och liv)
     */
    public void reInitGame(){
    	score = new ScoreType();
    	lives = 2;
		pauseGame();
		map = resourceManager.loadEmptyMap();
    }
    
    /**
     * Startar highscore
     */
    public void startHighscore(){

    	map = resourceManager.loadEmptyMap();
    	isPaused = true;
    	
    	Runtime rt = Runtime.getRuntime();
		try {
			rt.exec("rundll32 url.dll,FileProtocolHandler " +
					"http://www-und.ida.liu.se/~chrvi915/MoneyRun/index.php?page=highscore");
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    	//n�r man �r klar med highscoren
    	exit();
    }

    /**
     * Initierar InputManager
     */
    private void initInput() {
        moveLeft = new GameAction("moveLeft");
        moveRight = new GameAction("moveRight");
        
        jump = new GameAction("jump",
            GameAction.DETECT_INITAL_PRESS_ONLY);
        
        moveDown = new GameAction("moveDown",
        		GameAction.DETECT_INITAL_PRESS_ONLY);
        moveUp = new GameAction("moveUp",
        		GameAction.DETECT_INITAL_PRESS_ONLY);
        accept = new GameAction("accept", 
        		GameAction.DETECT_INITAL_PRESS_ONLY);
        menuLeft = new GameAction("menuLeft",
        		GameAction.DETECT_INITAL_PRESS_ONLY);
        menuRight = new GameAction("menuRight",
        		GameAction.DETECT_INITAL_PRESS_ONLY);
          
        pause = new GameAction("pause", 
        		GameAction.DETECT_INITAL_PRESS_ONLY);

        inputManager = new InputManager(
            screen.getFullScreenWindow());

        inputManager.mapToKey(moveLeft, KeyEvent.VK_LEFT);
        inputManager.mapToKey(moveRight, KeyEvent.VK_RIGHT);
        inputManager.mapToKey(jump, KeyEvent.VK_UP);
        inputManager.mapToKey(jump, KeyEvent.VK_SPACE);
         
        inputManager.mapToKey(pause, KeyEvent.VK_ESCAPE);
        inputManager.mapToKey(moveDown, KeyEvent.VK_DOWN);
        inputManager.mapToKey(moveUp, KeyEvent.VK_UP);
        inputManager.mapToKey(menuLeft, KeyEvent.VK_LEFT);
        inputManager.mapToKey(menuRight, KeyEvent.VK_RIGHT);
        inputManager.mapToKey(accept, KeyEvent.VK_ENTER);
        
    }
    
    
    /**
     * Pausar spelet
     */
    public void pauseGame(){
    	inputManager.mapToKey(moveUp, KeyEvent.VK_UP);
    	isPaused = true;
    }
    
    /**
     * Unpausar spelet
     */
    public void unpauseGame(){
    	inputManager.mapToKey(jump, KeyEvent.VK_UP);
    	isPaused = false; 
    }
    
    /**
     * Kollar om spelet �r pausat 
     * @return true om spelet �r pausat
     */
    public boolean isPaused(){
		return isPaused;
	}

	/**
     * Kollar efter input och uppdaterar 
     * @param elapsedTime tiden som g�tt sedan man kollade sist
     */
    private void checkInput(long elapsedTime) {

        if (isPaused()){

        	if (pause.isPressed()) {
        		if (resourceManager.getCurrentMap() != 0){
        			unpauseGame();
        		}
        	}
        	if (!menu.isInput()){
        		if (moveDown.isPressed()){
        			menu.setNextOption();
        		}
        		if (moveUp.isPressed()){
        			menu.setPerviousOption();
        		}
        	}
        	else {
        		if (pause.isPressed()){
        			//G�r ingenting
        		}
        		if (moveDown.isPressed()){
        			menu.setPreviousCharacter();
        		}
        		if (moveUp.isPressed()){
        			menu.setNextCharacter();
        		}
        		if (menuLeft.isPressed()){
        			menu.setPreviousCharacterSelecter();
        		}
        		if (menuRight.isPressed()){
        			menu.setNextCharacterSelecter();
        		}
        	}
        	if (accept.isPressed()){
        		menu.setSelcted(true);
        	}

        }
        
        if (pause.isPressed()) {
        		pauseGame();
        }
        
        Player player = (Player)map.getPlayer();
        
        if (player.isAlive()) {
            float velocityX = 0;
            if (moveLeft.isPressed()) {
                velocityX-=player.getMaxSpeed();
            }
            if (moveRight.isPressed()) {
                velocityX+=player.getMaxSpeed();
            }
            if (jump.isPressed()) {
                player.jump(false);
            }
            if (moveUp.isPressed() || moveDown.isPressed() || accept.isPressed()){
            	//G�r ingenting 
            }

            player.setVelocityX(velocityX);
        }

    }

    /**
     * Rita upp sk�rmen med TileMapRenders draw-funktion samt ritar upp aktuell po�ng. 
     * Om menyn �r aktiv ritas den upp.
     */
    public void draw(Graphics2D g) {
        renderer.draw(g, map,
            screen.getWidth(), screen.getHeight(),isPaused());
        
        //Rita upp po�ng och bana mm
        g.drawString("Namn: "+ score.getName() +" Score: "+score.getScore()+" Level: "+score.getLevel()+
        		" Lives left: "+lives, 30, 30);

        //Rita upp menyn
        if (isPaused()){
        	
        	if (!menu.isInput()){
        		menu.drawMenu(g, screen.getHeight(), screen.getWidth());
        	}
        	else {
        		menu.drawNameInput(g, screen.getHeight(), screen.getWidth());
        	}
        		
        }
    }


    /**
     * H�mtar nuvarande bana
     * @return banan
     */
    public TileMap getMap() {
        return map;
    }
    
    /**
     * H�mtar den tile som en sprite kolliderar med.  
     * @param sprite Spriten som kolliderar
     * @param newX nya x-kordinaten
     * @param newY nya y-kordinaten
     * @return nya positionen <p> null om ingen kollition hittad
     */
    public Point getTileCollision(Sprite sprite,
        float newX, float newY) {
    	
        float fromX = Math.min(sprite.getX(), newX);
        float fromY = Math.min(sprite.getY(), newY);
        float toX = Math.max(sprite.getX(), newX);
        float toY = Math.max(sprite.getY(), newY);

        // H�mta tilens plats
        int fromTileX = TileMapRenderer.pixelsToTiles(fromX);
        int fromTileY = TileMapRenderer.pixelsToTiles(fromY);
        int toTileX = TileMapRenderer.pixelsToTiles(
            toX + sprite.getWidth() - 1);
        int toTileY = TileMapRenderer.pixelsToTiles(
            toY + sprite.getHeight() - 1);

        // kolla alla tiles f�r kollition
        for (int x=fromTileX; x<=toTileX; x++) {
            for (int y=fromTileY; y<=toTileY; y++) {
                if (x < 0 || x >= map.getWidth() ||
                    map.getTile(x, y) != null)
                {
                    // kollition hittad
                    pointCache.setLocation(x, y);
                    return pointCache;
                }
            }
        }

        // ingen kollition hittad
        return null;
    }


    /**
     * Kollar om 2 sprites har kolliderat med varandra. 
     * @param s1 sprite 1
     * @param s2 sprite 2	
     * @return true om kollition och b�da sprites lever <p>
     * false annars, eller om de �r samma creature
     */
    public boolean isCollision(Sprite s1, Sprite s2) {
        // b�da sprites lika, returnera false
        if (s1 == s2) {
            return false;
        }

        // en av sprites �r d�da (creature), return false
        if (s1 instanceof Creature && !((Creature)s1).isAlive()) {
            return false;
        }
        if (s2 instanceof Creature && !((Creature)s2).isAlive()) {
            return false;
        }

        // h�mta pixelkordinaterna f�r sprites
        int s1x = Math.round(s1.getX());
        int s1y = Math.round(s1.getY());
        int s2x = Math.round(s2.getX());
        int s2y = Math.round(s2.getY());

        // kolla om sprites ramar �verlappar
        return (s1x < s2x + s2.getWidth() &&
            s2x < s1x + s1.getWidth() &&
            s1y < s2y + s2.getHeight() &&
            s2y < s1y + s1.getHeight());
    }


    /**
     * H�mtar Spriten som kolliderar med den specificerade Spriten
     * @param sprite som �r vald
     * @return sprite som kolliderar
     */
    public Sprite getSpriteCollision(Sprite sprite) {

        // G� igenom listan av sprites
        Iterator<Sprite> i = map.getSprites();
        while (i.hasNext()) {
            Sprite otherSprite = (Sprite)i.next();
            if (isCollision(sprite, otherSprite)) {
                // Kollition hittad, returnera Sprite
                return otherSprite;
            }
        }

        // Ingen kollition hittad
        return null;
    }
    
    /**
     * Startar om spelet fr�n f�rsta banan
     */
    public void startNewGame(){
    	
    	//Mappa om tangenter
        inputManager.mapToKey(moveLeft, KeyEvent.VK_LEFT);
        inputManager.mapToKey(moveRight, KeyEvent.VK_RIGHT);
               
    	lives=2;
		score = new ScoreType();
		
		map = resourceManager.loadFirstMap();
		score.setName(menu.getName());
    }

    /**
     * Uppdaterar Animation, position och hastighet f�r alla Sprites
     */
    public void update(long elapsedTime) {
        Creature player = (Creature)map.getPlayer();

        // Spelare d�d, ladda om banan
        if (player.getState() == Creature.STATE_DEAD) {
        	lives--;
        	score.addScore(-5000);
        	// spelet slut
        	if (lives < 0){
        		score.addToDatabase();
        		reInitGame();

        	}
        	else{
        		map = resourceManager.reloadMap();
        		return;
        	}
        }

        // H�mta input inputmanger
        checkInput(elapsedTime);
        
        // Spelet ig�ng
        if (!isPaused() || !isRunning){
        
        	// Uppdatera spelare
        	updateCreature(player, elapsedTime);
        	player.update(elapsedTime);

        	// Uppdatera andra sprites
        	Iterator<Sprite> i = map.getSprites();
        	while (i.hasNext()) {
        		Sprite sprite = (Sprite)i.next();
        		if (sprite instanceof Creature) {
        			Creature creature = (Creature)sprite;
        			if (creature.getState() == Creature.STATE_DEAD) {
        				i.remove();
        			}
        			else {
        				updateCreature(creature, elapsedTime);
        			}
        		}
        		// normal uppdatering
        		sprite.update(elapsedTime);
        	}
        }
        //Menyn �r uppe och man har gjort ett val
        if (menu.selected()){
        	 	
        	menu.setSelcted(false);
        	
        	if (!menu.isInput()){
        	
        		if (menu.getOption() == Menu.START_GAME){
        			
        			//mappa on tangenter 
        	        inputManager.mapToKey(menuLeft, KeyEvent.VK_LEFT);
        	        inputManager.mapToKey(menuRight, KeyEvent.VK_RIGHT);

        			
        			menu.startInput();

        		}
        		else if (menu.getOption() == Menu.EXIT_GAME){
        			stop();
        		}
        		else if (menu.getOption() == Menu.SEE_HIGHSCORE){
        			startHighscore();

        		}
        	}
        	else {
        		menu.stopInput();
        		unpauseGame();
        		startNewGame();
        	}
        }
    }


    /**
     * Uppdatera creature, inf�r gravitation f�r ickeflygande sprites,
     * kolla kollitionenr
     * @param creature Creature
     * @param elapsedTime Tiden som g�tt sedan senaste kollen
     */
    private void updateCreature(Creature creature, long elapsedTime) {

        // inf�r gravitation
        if (!creature.isFlying()) {
            creature.setVelocityY(creature.getVelocityY() + GRAVITY * elapsedTime);
        }

        // �ndra x-position
        float dx = creature.getVelocityX();
        float oldX = creature.getX();
        float newX = oldX + dx * elapsedTime;
        Point tile =
            getTileCollision(creature, newX, creature.getY());
        if (tile == null) {
            creature.setX(newX);
        }
        else {
        	// l�gg utanf�r tilesn inramning
            if (dx > 0) {
                creature.setX(TileMapRenderer.tilesToPixels(tile.x) - creature.getWidth());
            }
            else if (dx < 0) {
                creature.setX(TileMapRenderer.tilesToPixels(tile.x + 1));
            }
            creature.collideHorizontal();
        }
        if (creature instanceof Player) {
            checkPlayerCollision((Player)creature, false);
        }

        // �ndra y-position
        float dy = creature.getVelocityY();
        float oldY = creature.getY();
        float newY = oldY + dy * elapsedTime;
        tile = getTileCollision(creature, creature.getX(), newY);
        
        if (tile == null) {
            creature.setY(newY);
        }
        else {
            // l�gg utanf�r tilesn inramning
            if (dy > 0) {
                creature.setY(
                    TileMapRenderer.tilesToPixels(tile.y) - creature.getHeight());
            }
            else if (dy < 0) {
                creature.setY( TileMapRenderer.tilesToPixels(tile.y + 1));
            }
            creature.collideVertical();
        }
        if (creature instanceof Player) {
            boolean canKill = (oldY < creature.getY());
            checkPlayerCollision((Player)creature, canKill);
        }

    }

    /**
     * Kolla om player kolliderar med andra Sprites. Om player kan d�da
     * s� kommer kollitioner med creatures att d�da dem
     * @param player spelaren
     * @param canKill True om player kan d�da <br> false annars
     */
    public void checkPlayerCollision(Player player, boolean canKill) {
        
    	if (!player.isAlive()) {
            return;
        }

        // Kolla om spelaren kolliderar med andra sprites
        Sprite collisionSprite = getSpriteCollision(player);
        if (collisionSprite instanceof PowerUp) {
            acquirePowerUp((PowerUp)collisionSprite);
        }
        else if (collisionSprite instanceof Creature) {
            Creature badguy = (Creature)collisionSprite;
            if (canKill) {
                // D�da fienden och f� spelaren att hoppa
                badguy.setState(Creature.STATE_DYING);
                player.setY(badguy.getY() - player.getHeight());
                player.jump(true);
            }
            else {
                // spelaren d�r
                player.setState(Creature.STATE_DYING);
            }
        }
    }


    /**
     * Tar bort PowerUp fr�n bana och uppdaterar data f�r spelsessionen
     * beroende p� vilken typ av PowerUp det �r
     * @param powerUp Den PowerUp som �r aktuell
     */
    public void acquirePowerUp(PowerUp powerUp) {
        // Ta bort sprite
        map.removeSprite(powerUp);
        
        //Dollartecken
        if (powerUp instanceof PowerUp.Dollar) {
        	score.addScore(100);
            
        }
        //Nyckel
        else if (powerUp instanceof PowerUp.Goal) {
            
        	score.addScore(10000);
        	score.increaseLevel();
            map = resourceManager.loadNextMap();
            if (map == null){
            	score.addScore(10000*lives);
            	score.addToDatabase();
            	reInitGame();
            }
        }
        //Hj�rta
        else if (powerUp instanceof PowerUp.Heart){
        	lives++;
        }
    }

}