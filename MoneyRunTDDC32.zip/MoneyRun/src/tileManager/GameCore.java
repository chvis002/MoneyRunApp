package tileManager;

import java.awt.*;

import javax.swing.ImageIcon;

import graphics.ScreenManager;

/**
 * En enklare abrakt klass som anv�nds vid testning.
 * @author Christopher Visser & Victor S�derberg
 *
 */
public abstract class GameCore {

    protected static int FONT_SIZE = 24;

    private static final DisplayMode POSSIBLE_MODES[] = {
        new DisplayMode(800, 600, 16, 0),
        new DisplayMode(800, 600, 32, 0),
        new DisplayMode(800, 600, 24, 0),
        new DisplayMode(640, 480, 16, 0),
        new DisplayMode(640, 480, 32, 0),
        new DisplayMode(640, 480, 24, 0),
        new DisplayMode(1024, 768, 16, 0),
        new DisplayMode(1024, 768, 32, 0),
        new DisplayMode(1024, 768, 24, 0),
    };
    
    protected boolean isRunning;
    protected ScreenManager screen;


 
    /**
     * Singnalerar till gameloopen att det �r dags att sluta
     */
    public void stop() {
        isRunning = false;
    }


    /**
	 * Uppdaterar spelets/animationens l�ge(status) baserat p� den 
	 * tid som har paserat
	 * @param elapsedTime den tid som spelet k�rts
	 */
	public void update(long elapsedTime) {
	    // G�r inget h�r, men bra f�r underklasser
	}


	/**
	 * Startar fullsk�rmsl�ge och initierar objekt
	 */
	public void init() {
	    screen = new ScreenManager();
	    DisplayMode displayMode =
	        screen.findFirstCompatibleMode(POSSIBLE_MODES);
	    screen.setFullScreen(displayMode);
	
	    Window window = screen.getFullScreenWindow();
	    window.setFont(new Font("Dialog", Font.PLAIN, FONT_SIZE));
	    window.setBackground(Color.blue);
	    window.setForeground(Color.red);
	
	    isRunning = true;
	}


	/**
	 * K�r spelet tills man anropar stop()
	 */
	public void gameLoop() {
	    long startTime = System.currentTimeMillis();
	    long currTime = startTime;
	
	    while (isRunning) {
	        long elapsedTime =
	            System.currentTimeMillis() - currTime;
	        currTime += elapsedTime;
	
	        update(elapsedTime);

	        Graphics2D g = screen.getGraphics();

	        draw(g);
	        g.dispose();
	        screen.update();

	        // om man vill spara prestanda
	        /*try {
	            Thread.sleep(20);
	        }
	        catch (InterruptedException ex) { }*/
	    }
	}


	/**
     * Initierar och startar gameloopen
     */
    public void run() {
        try {
            init();
            gameLoop();
        }
        finally {
            screen.restoreScreen();
            exit();
        }
    }

    /**
     * Avslutar spelet.
     * 
     */
    public void exit(){
    	
    	System.exit(0);
    	
    }
    
    /**
     * Laddar image fr�n fil
     * @param fileName filens s�kv�g
     * @return bilden
     */
    public Image loadImage(String fileName) {
    	return new ImageIcon(fileName).getImage();
        
    }
    
    /**
     * S�tter textens storlek 
     * @param fontsize storleken i pt
     */
    protected void setFontSize(int fontsize){
    	FONT_SIZE = fontsize;
    }

    
    /**
     * Ritar sk�rmen. Underklasser m�ste overrida denna metod
     * @param g
     */
    public abstract void draw(Graphics2D g);
}