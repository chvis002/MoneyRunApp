package tileManager;

import java.awt.Graphics2D;
import java.awt.Image;
 

/**
 * Skapar en enklare Meny
 * @author Christopher Visser & Victor S�derberg
 *
 */
public class Menu{
	
	//Bilder
	private Image menuImage;
	private Image selectedImage;
	private Image nameInputImage;
	private Image nameInputSelecter;
	
	protected static int MENU_WIDTH;
	protected static int MENU_HIGHT;
	
	//M�jliga val
	protected static final int START_GAME = 0;
	protected static final int SEE_HIGHSCORE = 1;
	protected static final int EXIT_GAME = 2;
	
	//Det aktuella valet
	private int menuState = START_GAME;
	
	//Namnimatgnin
	private char[] name;
	private int characterSelecter;
	
	//Vilken meny som �r uppe
	private boolean isInput = false;
	
	//Om man gjort ett val
	private boolean selected = false;
	
	
	/**
	 * Skapar initierar menyn
	 * @param menuImage Menybilden
	 * @param selectedImage selecterBilden
	 * @param nameInputImage skriv in namn-bilden
	 */
	public Menu(Image menuImage, Image selectedImage, Image nameInputImage, Image nameInputSelecter ){
		this.menuImage = menuImage;
		this.selectedImage = selectedImage;
		this.nameInputImage = nameInputImage;
		this.nameInputSelecter = nameInputSelecter;
		
		MENU_HIGHT = menuImage.getHeight(null);
		MENU_WIDTH = menuImage.getWidth(null);
		
		name = new char[3];
		
		for (int i = 0; i < name.length; i++){
			name[i] = 'A';
		}
	}
	
	/**
	 * V�ljer n�sta val
	 */
	public void setNextOption(){
		
		menuState++;
		if (menuState > 2){
			menuState = 0;
		}
	}
	
	/**
	 * V�ljer f�reg�ende val
	 */
	public void setPerviousOption(){
		
		menuState--;
		if (menuState < 0) {
			menuState = 2;
		}
	}
	
	/**
	 * V�ljer n�sta bokstav 
	 */
	public void setNextCharacter(){
		if (name[characterSelecter] != 'Z'){
			name[characterSelecter]++;
		}
		else {
			name[characterSelecter] = 'A';
		}
	}
	
	/**
	 * V�ljer f�reg�ende bokstav 
	 */
	public void setPreviousCharacter(){
		if (name[characterSelecter] != 'A'){
			name[characterSelecter]--;
		}
		else {
			name[characterSelecter] = 'Z';
		}
	}
	
	/**
	 * V�ljer n�sta bokstav i namnet
	 */
	public void setNextCharacterSelecter(){
		if (characterSelecter != name.length-1){
			characterSelecter++;
		}
	}
	
	/**
	 * V�ljer f�reg�ende bokstav i namnet
	 */
	public void setPreviousCharacterSelecter(){
		if (characterSelecter != 0){
			characterSelecter--;
		}
	}

	/**
	 * Signalerar att inmatning av namn startat
	 */
	public void startInput(){
		this.isInput = true;
	}
	
	/**
	 * Singnalerar att inmatning av namn slutat
	 */
	public void stopInput(){
		this.isInput = false;
	}
	
	/**
	 * Kollar om inmatning av namn �r ig�ng
	 * @return <code>true</code> om inmatning ig�ng <br>
	 * @return <code>false</code> annars
	 */
	public boolean isInput(){
		return this.isInput;
	}
	
	/**
	 * Singnalerar att man vill v�lja ett menyval
	 * @param selected <code>true</code> om man vill v�lja
	 */
	public void setSelcted(boolean selected){
		this.selected = selected;
	}
	
	/**
	 * Kollar om man valt ett menyval
	 * @return <code>true</code> om man valt <br> <code>false<code> annars
	 */
	public boolean selected() {
		return selected;
	}
	/**
	 * H�mtar det aktuella valet
	 * @return menuState
	 */
	public int getOption(){
		return this.menuState;
	}
	
	/**
	 * H�mtar namnet som spelaren har matat in
	 * @return namnet
	 */
	public String getName(){
		String input = "";
		for (int i = 0; i < name.length; i++){
			input += name[i];
		}
		
		return input;
	}
	
	/**
	 * Ritar upp menyn mitt p� sk�rmen
	 * @param g grafiken
	 * @param screenHeight Sk�rmens h�jd
	 * @param screenWidth Sk�rmems bredd
	 */
	public void drawMenu(Graphics2D g, int screenHeight, int screenWidth){
		
    	
    	int x = (screenWidth-Menu.MENU_WIDTH)/2;
    	int y = (screenHeight-Menu.MENU_HIGHT)/2;
    	
    	g.drawImage(this.menuImage, x, y, null);
    	
    	g.drawImage(this.selectedImage, x-10, y+165 +73*menuState,null);
	}
	
	/**
	 * Ritar upp namninmatnings vyn mitt p� sk�rmen
	 * @param g grafiken
	 * @param screenHeight Sk�rmens h�jd
	 * @param screenWidth Sk�rmens bredd
	 */
	public void drawNameInput(Graphics2D g, int screenHeight, int screenWidth){
		
		int x = (screenWidth-nameInputImage.getWidth(null))/2;
		int y = (screenHeight-nameInputImage.getHeight(null))/2;
				
		g.drawImage(this.nameInputImage, x, y, null);
		g.drawString(this.getName(), screenWidth/2-10 , screenHeight/2+20);
		g.drawImage(this.nameInputSelecter, screenWidth/2-15+15*characterSelecter , screenHeight/2+20,null);
	}

}
