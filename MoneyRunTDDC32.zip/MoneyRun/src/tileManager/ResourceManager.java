package tileManager;


import java.awt.*;
import java.awt.geom.AffineTransform;
import java.io.*;
import java.util.ArrayList;
import javax.swing.ImageIcon;

import graphics.*;
import sprites.*;


/**
 * ResourceManager lagrar och hanterar bilder och Sprites.
 * @author Christopher Visser & Victor S�derberg
 *
 */
public class ResourceManager {

	private static final int NUMBER_OF_MAPS = 3;
	
    private ArrayList<Image> tiles;
    private int currentMap;
    private GraphicsConfiguration gc;

    // sprites som anv�nds f�r kloning 
    private Sprite playerSprite;
    private Sprite dollarSprite;
    private Sprite heartSprite;
    private Sprite goalSprite;
    private Sprite mushroomSprite;
    private Sprite rocketSprite;

    /**
     * Skapar en ny ResourceManager med en specificerad
     * GraphicsConfiguration
     * @param gc GraphicsConfiguration som g�ller
     */
    public ResourceManager(GraphicsConfiguration gc) {
        this.gc = gc;
        
        //Ladda mappen
        loadTileImages();
        loadCreatureSprites();
        loadPowerUpSprites();
    }

    /**
     * H�mtar en bild fr�n fil
     * @param name filens s�kv�g i mappen images/
     * @return bilden
     */
    public Image loadImage(String name) {
        String filename = "images/" + name;
        return new ImageIcon(filename).getImage();
    }

    /**
	 * Egen metod f�r att h�mta en avskalad image
	 * @param image Bilden som ska skalas
	 * @param x skalfaktor x-led	
	 * @param y skalfaktor y-led
	 * @return den skalade bilden
	 */
	private Image getScaledImage(Image image, float x, float y) {
	
	    // konfigurera transformatonen
	    AffineTransform transform = new AffineTransform();
	    transform.scale(x, y);
	    transform.translate(
	        (x-1) * image.getWidth(null) / 2,
	        (y-1) * image.getHeight(null) / 2);
	
	    // G�r bilden transparent
	    Image newImage = gc.createCompatibleImage(
	        image.getWidth(null),
	        image.getHeight(null),
	        Transparency.BITMASK);
	
	    // Rita den transformerade bilden
	    Graphics2D g = (Graphics2D)newImage.getGraphics();
	    g.drawImage(image, transform, null);
	    g.dispose();
	
	    return newImage;
	}

	/**
     * Skalar om bilden s� den blir spegelv�nd
     * @param image Bilden
     * @return bilden spegelv�nd
     */
    public Image getMirrorImage(Image image) {
        return getScaledImage(image, -1, 1);
    }

    /**
     * Skalar om bilden s� att den flippas i yled.
     * @param image Bilden som ska flippas	
     * @return en y-ledsflippad bild
     */
    public Image getFlippedImage(Image image) {
        return getScaledImage(image, 1, -1);
    }
    
    /**
     * H�mtar vilken bana som �r aktuell
     * @return indexet f�r banan
     */
    public int getCurrentMap(){
    	return currentMap;
    }
    
    /**
     * Laddar f�rsta banan
     * @return map1.txt
     */
    public TileMap loadFirstMap() {
    	TileMap map = null;
    	currentMap = 1;
    	try {
			map = loadMap("maps/map1.txt");
		} catch (IOException e) {
			e.printStackTrace();
		}
    	return map;
	}


	/**
     * Laddar in n�sta bana
     * @return en ny TileMap<p>null om man klarat spelet
     */
    public TileMap loadNextMap() {
        TileMap map = null;

        currentMap++;
        try {
        	map = loadMap("maps/map" + currentMap + ".txt");
        }
        catch (IOException ex) {
        	if (currentMap > NUMBER_OF_MAPS) {
        		//Nu har man klarat spelet
        		return null;
        	}
        	currentMap = 0;
        	map = null;
        }

        return map;
    }
    
    /**
     * Laddar en tom bana
     * @return en bana utan tiles
     */
    public TileMap loadEmptyMap(){
    	TileMap map = null;
    	try {
			map = loadMap("maps/emptymap.txt");
			currentMap = 0;
		} catch (IOException e) {
			
			e.printStackTrace();
		}
    	return map;
    }
    
    /**
     * Ladda om banan
     * @return den omladdade banan
     */
    public TileMap reloadMap() {
        try {
            return loadMap(
                "maps/map" + currentMap + ".txt");
        }
        catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    /**
     * L�ser in en tilemap fr�n textfil
     * @param filename textfilens s�kv�g
     * @return en Tilemap
     * @throws IOException
     */
    
    private TileMap loadMap(String filename)throws IOException {
        
    	ArrayList<String> lines = new ArrayList<String>();
        int width = 0;
        int height = 0;

        // L�s in alla rader in i listan
        BufferedReader reader = new BufferedReader(
            new FileReader(filename));
        while (true) {
            String line = reader.readLine();
           
            if (line == null) {
                reader.close();
                break;
            }

            // L�s in alla rader som inte �r kommenterade
            if (!line.startsWith("#")) {
                lines.add(line);
                width = Math.max(width, line.length());
            }
        }

        // parsa om raderna f�r att skapa en tilemotor
        height = lines.size();
        TileMap newMap = new TileMap(width, height);
        for (int y=0; y<height; y++) {
            String line = (String)lines.get(y);
            for (int x=0; x<line.length(); x++) {
                char ch = line.charAt(x);

                // kolla om bokstaven representerar tile A,B etc.
                int tile = ch - 'A';
                if (tile >= 0 && tile < tiles.size()) {
                    newMap.setTile(x, y, (Image)tiles.get(tile));
                }

                // kolla om bokstaven representerar en sprite
                else if (ch == 'o') {
                    addSprite(newMap, dollarSprite, x, y);
                }
                else if (ch == 'h') {
                	addSprite(newMap, heartSprite, x, y);
                }
                else if (ch == '*') {
                    addSprite(newMap, goalSprite, x, y);
                }
                else if (ch == '1') {
                    addSprite(newMap, mushroomSprite, x, y);
                }
                else if (ch == '2') {
                    addSprite(newMap, rocketSprite, x, y);
                }
            }
        }

        // L�gg till spelaren p� banan
        Sprite player = (Sprite)playerSprite.clone();
        player.setX(TileMapRenderer.tilesToPixels(3));
        player.setY(0);
        newMap.setPlayer(player);

        return newMap;
    }

    /**
     * L�gg till en sprite i banan mha cloning
     * @param map banan som spriten ska l�ggas till
     * @param hostSprite typen av sprite som ska klonas	
     * @param tileX	Vilken tile i x-led
     * @param tileY	vilken tile i y-led
     */
    private void addSprite(TileMap map,
        Sprite hostSprite, int tileX, int tileY){
       
    	if (hostSprite != null) {
            // clone the sprite from the "host"
            Sprite sprite = (Sprite)hostSprite.clone();

            // center the sprite
            sprite.setX(
                TileMapRenderer.tilesToPixels(tileX) +
                (TileMapRenderer.tilesToPixels(1) -
                sprite.getWidth()) / 2);

            // bottom-justify the sprite
            sprite.setY(
                TileMapRenderer.tilesToPixels(tileY + 1) -
                sprite.getHeight());

            // add it to the map
            map.addSprite(sprite);
        }
    }

    /**
     * Ladda tilebilderna
     */
    public void loadTileImages() {
        // keep looking for tile A,B,C, etc. this makes it
        // easy to drop new tiles in the images/ directory
        tiles = new ArrayList<Image>();
        char ch = 'A';
        while (true) {
            String name = "tile_" + ch + ".png";
            File file = new File("images/" + name);
            if (!file.exists()) {
                break;
            }
            tiles.add(loadImage(name));
            ch++;
        }
    }

    /**
     * Ladda sprites
     */
    public void loadCreatureSprites() {

        Image[][] images = new Image[4][];

        // ladda v�nsterriktade bilder
        images[0] = new Image[] {
            loadImage("player1.png"),
            loadImage("player2.png"),
            loadImage("rocket1.png"),
            loadImage("rocket2.png"),
            loadImage("mushroom.png"),
        };
        
        //l�gg till arrayer f�r h�ger- och/resp uppochner bilder
        images[1] = new Image[images[0].length];
        images[2] = new Image[images[0].length];
        images[3] = new Image[images[0].length];
        for (int i=0; i<images[0].length; i++) {
            // h�gerriktade
            images[1][i] = getMirrorImage(images[0][i]);
            // v�nser uppochner 
            images[2][i] = getFlippedImage(images[0][i]);
            // h�ger uppochner
            images[3][i] = getFlippedImage(images[1][i]);
        }

        // Skapa animationer f�r creatures
        Animation[] playerAnim = new Animation[4];
        Animation[] flyAnim = new Animation[4];
        Animation[] grubAnim = new Animation[4];
        for (int i=0; i<4; i++) {
            playerAnim[i] = createPlayerAnim(
                images[i][0], images[i][1]);
            flyAnim[i] = createRocketAnim(
                images[i][2], images[i][3]);
            grubAnim[i] = createMushroomAnim(
                images[i][4]);
        }

        // Skapa creatures
        playerSprite = new Player(playerAnim[0], playerAnim[1],
            playerAnim[2], playerAnim[3]);
        rocketSprite = new Rocket(flyAnim[0], flyAnim[1],
            flyAnim[2], flyAnim[3]);
        mushroomSprite = new Mushroom(grubAnim[0], grubAnim[1],
            grubAnim[2], grubAnim[3]);
    }

    /**
     * Skapa animation f�r Player
     * @param player1 frame 1
     * @param player2 frame 2
     * @return animationen
     */
    private Animation createPlayerAnim(Image player1,
        Image player2) {
       
    	Animation anim = new Animation();
        anim.addFrame(player1, 600);
        anim.addFrame(player2, 200);


        return anim;
    }

    /**
     * Skapa animation f�r flygande creature
     * @param img1 frame 1
     * @param img2 frame 2
     * @return animationen
     */
    private Animation createRocketAnim(Image img1, Image img2) {
        Animation anim = new Animation();
        anim.addFrame(img1, 100);
        anim.addFrame(img2, 100);
        return anim;
    }

    /**
     * Skapa animation f�r landcreature
     * @param img1 frame 1
     * @return
     */
    private Animation createMushroomAnim(Image img1) {
        Animation anim = new Animation();
        anim.addFrame(img1, 10000);
        return anim;
    }

    /**
     * Ladda powerups 
     */
    private void loadPowerUpSprites() {
        // create "goal" sprite
        Animation anim = new Animation();
        anim.addFrame(loadImage("key1.png"), 200);
        anim.addFrame(loadImage("key2.png"), 200);
        goalSprite = new PowerUp.Goal(anim);

        // create dollar sprite
        anim = new Animation();
        anim.addFrame(loadImage("dollar1.png"), 200);
        anim.addFrame(loadImage("dollar2.png"), 200);
        anim.addFrame(loadImage("dollar3.png"), 200);
        dollarSprite = new PowerUp.Dollar(anim);
        
        //Skapa hj�rta sprite
        anim = new Animation();
        anim.addFrame(loadImage("heart1.png"), 150);
        anim.addFrame(loadImage("heart2.png"), 150);
        anim.addFrame(loadImage("heart3.png"), 150);
        anim.addFrame(loadImage("heart2.png"), 150);
        heartSprite = new PowerUp.Heart(anim);
        


    }

}
