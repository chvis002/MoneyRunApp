package tileManager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Lagrar scoren som ska anv�ndas i highscoren. Klassen kan �ven posta sig sj�lv
 * till en databas.
 */
public class ScoreType {
	
	private String name;
	private int level;
	private int score;
	
	/**
	 * Anv�nds f�r initiering av klassen
	 */
	public ScoreType() {
		level = 1;
		score = 0;
		name = " ";
	}
	
	/**
	 * Lagrar aktuella v�rden som noden innehar 
	 * @param name, spelarens namn
	 * @param level, senaste niv� som avklarats		
	 * @param score, po�ng		
	 */
	public ScoreType(String name, int level, int score) {
		this.name = name;
		this.level = level;
		this.score = score;
	}
	
	/**
	 * L�gg till po�ng i score
	 * @param points antalet inh�mtade po�ng
	 */
	public void addScore(int points){
		score += points;
	}
	
	/**
	 * S�tter spelarens namn till scoren
	 * @param name Spelarens namn
	 */
	public void setName(String name){
		this.name = name;
	}
	
	/**
	 * �ka scorens level med 1
	 */
	public void increaseLevel(){
		level++;
	}
	
	/**
	 * Returnerar spelarens namn
	 * @return spelarens namn
	 */
	public String getName(){
		return name;
	}
	
	/**
	 * Returnerar senaste niv� som avklarats		
	 * @return senaste niv� som avklarats		
	 */
	public int getLevel(){
		return level;
	}
	
	/**
	 * Returnerar po�ng	
	 * @return po�ng	
	 */
	public int getScore(){
		return score;
	}
	
	/**
	 * L�gg till scoren i databasen
	 */
	public void addToDatabase(){

		//laddar JDBC driver och initierar en instance
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (Exception e) {
			System.out.println( "Kan inte ladda driver-klassen" );
		}
		try{
			//skapar en databaskoppling
			Connection dbconn = DriverManager.getConnection("jdbc:mysql://www-und.ida.liu.se/chrvi915",
					"chrvi915", "chrvi915e17d");

			//skapar ett JDBC statement object
			Statement s = dbconn.createStatement();
			s.executeUpdate("INSERT INTO highscore ( name, level, score) VALUES ('" + name + "', " + level + ", " + score + ");");
			s.close();
			dbconn.close();
		}
		catch(SQLException x ){
			System.out.println( "Kunde inte skapa en databaskoppling" );
		}


	}
	
}